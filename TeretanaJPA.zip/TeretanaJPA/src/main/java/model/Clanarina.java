package model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the clanarina database table.
 * 
 */
@Entity
@NamedQuery(name="Clanarina.findAll", query="SELECT c FROM Clanarina c")
public class Clanarina implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int idC;

	@Temporal(TemporalType.DATE)
	private Date datumDo;

	@Temporal(TemporalType.DATE)
	private Date datumOd;

	//bi-directional many-to-one association to Tipmusterije
	@ManyToOne
	@JoinColumn(name="idTipaM")
	private Tipmusterije tipmusterije;

	//bi-directional many-to-one association to Musterija
	@OneToMany(mappedBy="clanarina")
	private List<Musterija> musterijas;

	public Clanarina() {
	}

	public int getIdC() {
		return this.idC;
	}

	public void setIdC(int idC) {
		this.idC = idC;
	}

	public Date getDatumDo() {
		return this.datumDo;
	}

	public void setDatumDo(Date datumDo) {
		this.datumDo = datumDo;
	}

	public Date getDatumOd() {
		return this.datumOd;
	}

	public void setDatumOd(Date datumOd) {
		this.datumOd = datumOd;
	}

	public Tipmusterije getTipmusterije() {
		return this.tipmusterije;
	}

	public void setTipmusterije(Tipmusterije tipmusterije) {
		this.tipmusterije = tipmusterije;
	}

	public List<Musterija> getMusterijas() {
		return this.musterijas;
	}

	public void setMusterijas(List<Musterija> musterijas) {
		this.musterijas = musterijas;
	}

	public Musterija addMusterija(Musterija musterija) {
		getMusterijas().add(musterija);
		musterija.setClanarina(this);

		return musterija;
	}

	public Musterija removeMusterija(Musterija musterija) {
		getMusterijas().remove(musterija);
		musterija.setClanarina(null);

		return musterija;
	}

}