package model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the komentar database table.
 * 
 */
@Entity
@NamedQuery(name="Komentar.findAll", query="SELECT k FROM Komentar k")
public class Komentar implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int idKom;

	private String text;

	//bi-directional many-to-one association to Musterija
	@ManyToOne
	@JoinColumn(name="idMusterije")
	private Musterija musterija;

	public Komentar() {
	}

	public int getIdKom() {
		return this.idKom;
	}

	public void setIdKom(int idKom) {
		this.idKom = idKom;
	}

	public String getText() {
		return this.text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public Musterija getMusterija() {
		return this.musterija;
	}

	public void setMusterija(Musterija musterija) {
		this.musterija = musterija;
	}

}