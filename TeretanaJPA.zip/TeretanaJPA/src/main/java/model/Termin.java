package model;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the termin database table.
 * 
 */
@Entity
@NamedQuery(name="Termin.findAll", query="SELECT t FROM Termin t")
public class Termin implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int idT;

	@Temporal(TemporalType.DATE)
	private Date datum;

	private int indikatorPopunjenosti;

	private String vreme;

	//bi-directional many-to-one association to Usluga
	@ManyToOne
	@JoinColumn(name="idUsluge")
	private Usluga usluga;

	//bi-directional many-to-one association to Zaposleni
	@ManyToOne
	@JoinColumn(name="idZap")
	private Zaposleni zaposleni;
	
	@ManyToMany(fetch = FetchType.EAGER, mappedBy="termins")
	private Set<Musterija> musterijas =new HashSet<>();

	public Termin() {
	}

	public int getIdT() {
		return this.idT;
	}

	public void setIdT(int idT) {
		this.idT = idT;
	}

	public Date getDatum() {
		return this.datum;
	}

	public void setDatum(Date datum) {
		this.datum = datum;
	}

	public int getIndikatorPopunjenosti() {
		return this.indikatorPopunjenosti;
	}

	public void setIndikatorPopunjenosti(int indikatorPopunjenosti) {
		this.indikatorPopunjenosti = indikatorPopunjenosti;
	}

	public String getVreme() {
		return this.vreme;
	}

	public void setVreme(String vreme) {
		this.vreme = vreme;
	}

	public Usluga getUsluga() {
		return this.usluga;
	}

	public void setUsluga(Usluga usluga) {
		this.usluga = usluga;
	}

	public Zaposleni getZaposleni() {
		return this.zaposleni;
	}

	public void setZaposleni(Zaposleni zaposleni) {
		this.zaposleni = zaposleni;
	}

	public Set<Musterija> getMusterijas() {
		return musterijas;
	}

	public void setMusterijas(Set<Musterija> musterijas) {
		this.musterijas = musterijas;
	}
	
	

}