package model;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQuery;


/**
 * The persistent class for the uloga database table.
 * 
 */
@Entity
@NamedQuery(name="Uloga.findAll", query="SELECT u FROM Uloga u")
public class Uloga implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int idUlg;


	private String nazivUlg;
	
	@ManyToMany(fetch = FetchType.EAGER)
	@JoinTable(name="uloga_korisnik", joinColumns = @JoinColumn(name = "idU",referencedColumnName = "idUlg"),inverseJoinColumns = @JoinColumn(name = "idK"))
	private Set<Korisnik> korisniks =new HashSet<>();

	public Uloga() {
	}

	public int getIdUlg() {
		return this.idUlg;
	}

	public void setIdUlg(int idUlg) {
		this.idUlg = idUlg;
	}



	public String getNazivUlg() {
		return this.nazivUlg;
	}

	public void setNazivUlg(String nazivUlg) {
		this.nazivUlg = nazivUlg;
	}

	public Set<Korisnik> getKorisniks() {
		return korisniks;
	}

	public void setKorisniks(Set<Korisnik> korisniks) {
		this.korisniks = korisniks;
	}

}