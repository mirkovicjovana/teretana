package beans;

import java.util.List;

import managers.UlogaManager;
import model.Uloga;

public class BeanUloge {

	private List<Uloga> uloge;
	
	public BeanUloge() {
		UlogaManager um = new UlogaManager();
		uloge = um.getSveUloge();
	}

	public List<Uloga> getUloge() {
		return uloge;
	}

	public void setU(List<Uloga> u) {
		this.uloge = u;
	}
	
	
}