package com.example.demo.controller;

import java.io.File;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;

import com.example.demo.domain.UslugaSlika;
import com.example.demo.repository.ClanarinaRepository;
import com.example.demo.repository.FotografijaRepository;
import com.example.demo.repository.KorisnikRepository;
import com.example.demo.repository.MusterijaRepository;
import com.example.demo.repository.SmenaRepository;
import com.example.demo.repository.TerminRepository;
import com.example.demo.repository.TipmusterijeRepository;
import com.example.demo.repository.TipuslugeRepository;
import com.example.demo.repository.UlogaRepository;
import com.example.demo.repository.UslugaRepository;
import com.example.demo.repository.ZaposleniRepository;

import model.Clanarina;
import model.Fotografija;
import model.Korisnik;
import model.Musterija;
import model.Smena;
import model.Termin;
import model.Tipmusterije;
import model.Tipusluge;
import model.Uloga;
import model.Usluga;
import model.Zaposleni;

@Controller
@ControllerAdvice
@RequestMapping(value="/admin")
public class AdministratorController {
	
	@PersistenceContext
	EntityManager em;
	
	@Autowired
	TipuslugeRepository tur;
	
	@Autowired
	UslugaRepository ur;
	
	@Autowired
	KorisnikRepository kr;
	
	@Autowired
	ZaposleniRepository zr;
	
	@Autowired
	SmenaRepository sr;
	
	@Autowired
	UlogaRepository ulr;
	
	@Autowired
	TerminRepository tr;
	
	@Autowired
	FotografijaRepository fr;

	@Autowired
	TipmusterijeRepository tmr;
	
	@Autowired
	MusterijaRepository mr;
	
	@Autowired
	ClanarinaRepository cr;
	
	@RequestMapping(value = "/tipoviUsluga", method = RequestMethod.GET)
	public String listaTipovaUsluga(Model m) {
//		String query="SELECT t FROM Tipusluge t";
//		Query q=em.createQuery(query);
//		List<Tipusluge> tipoviUsluge=q.getResultList();
		List<Tipusluge> tipoviUsluge=tur.findAll();
		m.addAttribute("tipoviUsluga", tipoviUsluge);
		return "tipoviUsluga";
	}
	
	@RequestMapping(value = "/spisakUsluga", method = RequestMethod.GET)
	public String spisakUslugaOdredjenogTipa(HttpServletRequest request,Model m) {
		//1-grupniTrening
		//2-individualniTrening
		//3-spa
		
		//id selektovan u comboBoxu
		Integer id=Integer.parseInt(request.getParameter("idTipa"));
		Tipusluge tip=tur.findById(id).get();
		request.getSession().setAttribute("tipUsluge", tip);

		List<Usluga> listaUsluga=ur.findAllByTipusluge(tip);
		
		
		m.addAttribute("usluge", listaUsluga);
		
		return "spisakUsluga";
	}
	
	@RequestMapping(value = "/prikazUsluge", method = RequestMethod.GET)
	public String prikazUsluge(HttpServletRequest request,Model m) {
		Integer id=Integer.parseInt(request.getParameter("idU"));
		Usluga u=ur.getById(id);
		request.getSession().setAttribute("usluga", u);
		return "spisakUsluga";
	}
	
	
	@RequestMapping(value = "/brisanjeTipa", method = RequestMethod.GET)
	public String brisanjeTipaUsluge(HttpServletRequest request) {
		String uspesnoObrisano="";
		
		//Integer id=Integer.parseInt(request.getParameter("idTipa"));
		Integer id=Integer.parseInt(request.getParameter("tipUsluge"));
		
		try {
		Tipusluge t=tur.findById(id).get();
		tur.delete(t);
		uspesnoObrisano="Uspesno ste obrisali tip usluge iz baze podataka.";
		}catch(Exception ex) {
			ex.printStackTrace();
			uspesnoObrisano="Niste uspeli obrisati tip usluge iz baze podataka.";
		}
		
		request.getSession().setAttribute("uspesnoObrisano", uspesnoObrisano);
		return "tipoviUsluga";
	}
	
	@RequestMapping(value = "/unosVrsteUsluga", method = RequestMethod.POST)
	public String unosVrsteUsluga(String naziv, HttpServletRequest request) {
		String poruka="";
		try {
		Tipusluge t=new Tipusluge();
		t.setNazivTipa(naziv);
		tur.save(t);
		poruka= "Uspesno ste dodali novu vrstu usluga";

		}catch(Exception ex) {
			ex.printStackTrace();
			poruka= "Niste uspeli da dodate novu vrstu usluga.";
		}
		
		request.getSession().setAttribute("poruka", poruka);

		return "unosVrsteUsluga";
	}
	
	
	@RequestMapping(value = "/sveUslugeCB", method = RequestMethod.GET)
	public String sveUslugeCB(HttpServletRequest request,Model m) {
		List<Usluga> usluge=ur.findAll();
		request.getSession().setAttribute("uslugeCB",usluge);
		return "unosZaposlenog";
	}
	
	@RequestMapping(value = "/sveUslugeCB2", method = RequestMethod.GET)
	public String sveUslugeCB2(HttpServletRequest request,Model m) {
		List<Usluga> usluge=ur.findAll();
		request.getSession().setAttribute("uslugeCB2",usluge);
		return "unosTermina";
	}
	
	//moram imati isti metod da me ne bi bacilo na pogresnu stranicu
	@RequestMapping(value = "/sveUsluge", method = RequestMethod.GET)
	public String sveUsluge(HttpServletRequest request,Model m) {
		List<Usluga> usluge=ur.findAll();
		m.addAttribute("usluge",usluge);
		return "tipoviUsluga";
	}
	
	@RequestMapping(value = "/formaUsluga", method = RequestMethod.GET)
	public String formaUsluge(HttpServletRequest request,Model m) {
			String forma="forma";
			m.addAttribute("slika", new UslugaSlika());
			m.addAttribute("forma", forma);
			return "spisakUsluga";
		}
	
	
	@RequestMapping(value = "/unosUsluge", method = RequestMethod.POST)
	public String unosUsluge(HttpServletRequest request,Model m,String naziv,Integer cena,UslugaSlika slika) {
		
		String uspesanUnosUsluge="";
		MultipartFile file = slika.getSlika();
		if (null != file) {
			String fileName = file.getOriginalFilename();
			String filePath;
			try {
				filePath = System.getProperty("user.dir");
				//System.out.println("Putanja je "+filePath);
				File imageFile = new File(filePath, fileName);
				file.transferTo(imageFile);

				Usluga u=new Usluga();
				u.setNaziv(naziv);
				Tipusluge tip=(Tipusluge) request.getSession().getAttribute("tipUsluge");
				u.setTipusluge(tip);
				u.setCena(cena);
				u.setSlika(Files.readAllBytes(imageFile.toPath()));
				ur.save(u);
				request.getSession().setAttribute("usluga", u);
				uspesanUnosUsluge="Uspesno ste uneli novu uslugu.";
			} catch (Exception e) {
				e.printStackTrace();
				uspesanUnosUsluge="Niste uspesno uneli novu uslugu.";
			}
		}

		request.getSession().setAttribute("uspesanUnosUsluge", uspesanUnosUsluge);

		return "spisakUsluga";
	}
	
	
	//Zaposlenog unosi administrator u sistem i on mu smislja sifru
	@RequestMapping(value = "/unosZaposlenog", method = RequestMethod.POST)
	public String unosZaposlenog(HttpServletRequest request,Model m,String ime, String prezime,String brlk,Integer plata,
			String username, String password, Integer idSmene, Integer idUsluge) {
		
		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		//BCryptPasswordEncoder passwordEncoder2 = new BCryptPasswordEncoder();
		String nova_sif=passwordEncoder.encode(password);

		//System.out.println(password);
		
		String poruka="";
		try {
		Korisnik k=new Korisnik();
		Zaposleni z=new Zaposleni();
		
		k.setIme(ime);
		k.setPrezime(prezime);
		k.setUsername(username);
		k.setPassword(nova_sif);
		
		Uloga uloga=ulr.getById(2); //zaposleni ima id 2, a znamo da je ovo zapolsnei jer bas njega unosimo
		k.getUlogas().add(uloga);
		for(Uloga u:k.getUlogas()) {
			u.getKorisniks().add(k);
		}
		
		Integer idKorisnika=k.getIdK();
		
		kr.save(k);
		
		Smena s=sr.findById(idSmene).get();
		Usluga u=ur.findById(idUsluge).get();
		
		z.setIme(ime);
		z.setPrezime(prezime);
		z.setUsername(username);
		z.setPassword(nova_sif);
		z.setPlata(plata);
		z.setBrlk(brlk);
		z.setSmena(s);
		z.setUsluga(u);
		
		z.setIdZ(idKorisnika);
		zr.save(z);
		
		poruka= "Uspesno ste dodali novog zaposlenog";
	
		}catch(Exception ex) {
			ex.printStackTrace();
			poruka= "Niste uspeli da dodate zaposlenog.Pokusjte ponovo.";
		}
		m.addAttribute("poruka",poruka);
		return "unosZaposlenog";
	}
	
	@RequestMapping(value = "/sviZaposleni", method = RequestMethod.GET)
	public String sviZaposleni(HttpServletRequest request,Model m) {
		List<Zaposleni> zap=zr.findAll();
		request.getSession().setAttribute("zaposleni",zap);
		return "zaposleni";
	}
	
	//ovaj metod sluzi da nam prosledi idZaposlenog na sledecu jsp stranicu za prikaz zap
	@RequestMapping(value = "/prikazZaposlenog", method = RequestMethod.GET)
	public String prikazZaposlenog(HttpServletRequest request,Model m) {
		Integer idZ=Integer.parseInt(request.getParameter("idZ"));
		request.getSession().setAttribute("idZaposlenog", idZ);
		Zaposleni z=zr.getById(idZ);
		m.addAttribute("zaposleni",z);
		return "prikazZaposlenog";
	}
	
	@RequestMapping(value = "/brisanjeZaposlenog", method = RequestMethod.GET)
	public String brisanjeZaposlenog(HttpServletRequest request,Model m) {
		String uspesnoObrisano="";
		
		try {
		//Integer id=(Integer) request.getSession().getAttribute("idZaposlenog");
		Integer id=Integer.parseInt(request.getParameter("idZ"));
		System.out.println(id+"\n");
		Zaposleni z=zr.findById(id).get(); //mogli smo i iz modela izvuci
		System.out.println(z+"\n");
		String username=z.getUsername();
		Korisnik k=kr.findByUsername(username);
		System.out.println(k+"\n");
		
		zr.delete(z);
		System.out.println("Puklo posle zr.del\n");
		kr.delete(k);
		System.out.println("Puklo posle kr.del\n");

		
		uspesnoObrisano="Uspesno ste obrisali zaposlenog iz baze podataka.";
		}catch(Exception ex) {
			ex.printStackTrace();
			uspesnoObrisano="Niste uspeli obrisati zaposlenog iz baze podataka.";

		}
		m.addAttribute("porukaBrisanje", uspesnoObrisano);
		return "prikazZaposlenog";
	}
	
	@RequestMapping(value = "/azuriranje", method = RequestMethod.POST)
	public String updatePodatakaZaposlenog(HttpServletRequest request) {
		Integer id=(Integer) request.getSession().getAttribute("idZaposlenog");
		Zaposleni z=zr.getById(id);
		String plata=request.getParameter("novaPlata");
		String smena=request.getParameter("smena");
		
		String uspesnoAzuriranje="";
		
		if(plata!=null) {
			Integer novaPlata=Integer.parseInt(plata);
			
			try {
				z.setPlata(novaPlata);
				zr.save(z);
				uspesnoAzuriranje="Uspesno azuriranje zaposlenog";
			}catch(Exception ex) {
				ex.printStackTrace();
				uspesnoAzuriranje="Niste uspeli da azurirate zaposlenog";
			}
			
		}else if(smena!=null) {
			try {
			Integer idSmene=Integer.parseInt(smena);
			z.setSmena(sr.getById(idSmene));
			zr.save(z);
			uspesnoAzuriranje="Uspesno azuriranje zaposlenog";
			}catch(Exception ex) {
				ex.printStackTrace();
				uspesnoAzuriranje="Niste uspeli da azurirate zaposlenog";
			}
			
			request.getSession().setAttribute("uspesnoAzuriranje", uspesnoAzuriranje);
		}
		return "prikazZaposlenog";
		}
	
	
	@RequestMapping(value = "/prikaziAzuriranja", method = RequestMethod.GET)
	public String prikaziMogucnostiZaAzuriranja(Model m) {
		
		String prikazi="prikazi";
		m.addAttribute("prikazi", prikazi);
		return "prikazZaposlenog";
	}
	
	@RequestMapping(value = "/zaposleniUsluga", method = RequestMethod.GET)
	public String sviZaposleniKojiObavljajuUslugu(HttpServletRequest request,Model m) {
			Integer id=Integer.parseInt(request.getParameter("idUsluge"));
			request.getSession().setAttribute("idUsluge", id);
			Usluga usl=ur.findById(id).get();
			List<Zaposleni> zaposleni=zr.findAllByUsluga(usl);
			
			request.getSession().setAttribute("zaposleniUsluga", zaposleni);
			return "unosTermina";
		}

	//unosTermina
	@RequestMapping(value = "/unosTermina", method = RequestMethod.POST)
	public String unosTermina(HttpServletRequest request,Date datum,String vreme) {
		String uspesanTermin="";
		
		Integer idZaposlenog=Integer.parseInt(request.getParameter("idZaposlenog"));
		Zaposleni z=zr.findById(idZaposlenog).get();
		Integer idUsluge=(Integer) request.getSession().getAttribute("idUsluge");
		Usluga u=ur.getById(idUsluge);
		
		try {
		Termin t=new Termin();
		t.setDatum(datum);
		t.setVreme(vreme);
		t.setUsluga(u);
		t.setZaposleni(z);

		tr.save(t);
		uspesanTermin="Uspesno dodat termin.";
		}catch(Exception ex) {
			ex.printStackTrace();
			uspesanTermin="Niste uspeli dodati termin.";
		}

		request.getSession().setAttribute("uspesanTermin", uspesanTermin);
		
		return "unosTermina";
	}
	
	@RequestMapping(value = "/sveUslugeCB3", method = RequestMethod.GET)
	public String sveUslugeUnosFotoURL(HttpServletRequest request,Model m) {
		List<Usluga> usluge=ur.findAll();
		request.getSession().setAttribute("uslugeCB3",usluge);
		return "unosFotografije";
	}
	
	@RequestMapping(value = "/unosFotografije", method = RequestMethod.POST)
	public String unosFotografije(HttpServletRequest request,String url) {
		String uspesnaFoto="";
		try {
		Fotografija f=new Fotografija();
		Integer idUsluge=Integer.parseInt(request.getParameter("idUsluge"));
		Usluga u=ur.getById(idUsluge);
		f.setUrl(url);
		f.setUsluga(u);
		fr.save(f);
		uspesnaFoto="Uspesno dodata fotografija.";
		}catch(Exception ex) {
			ex.printStackTrace();
			uspesnaFoto="Niste uspeli dodati fotografiju.";
		}
		
		request.getSession().setAttribute("uspesnaFoto",uspesnaFoto);
		return "unosFotografije";
	}
	
	
	@RequestMapping(value = "/tipoviMusterijeCB", method = RequestMethod.GET)
	public String tipoviMusterijeCB(HttpServletRequest request) {
		List<Tipmusterije> tm=tmr.findAll();
		request.getSession().setAttribute("tipoviMusterijeCB",tm);
		return "unosMusterije";
	}
	
	//dodati GlavnogZaposlenog i prebaciti ovaj metod kod njega-Musterija dodje na pult i 
	//taj zaposleni je unese u sistem(a trenutno to radi Admin)
	//on dodeli username i password musteriji
	//ali ona ima mogucnost da promeni to
		@RequestMapping(value = "/unosMusterije", method = RequestMethod.POST)
		public String unosMusterije(HttpServletRequest request,String ime,String prezime,
				String username, String password,String brlk,Date datumOd,Date datumDo) {
			String uspesnaMusterija="";
			BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
			//BCryptPasswordEncoder passwordEncoder2 = new BCryptPasswordEncoder();
			String nova_sif=passwordEncoder.encode(password);

			
			try {
			Clanarina c=new Clanarina();		
			Integer idTM=Integer.parseInt(request.getParameter("idTipaMusterije"));
			Tipmusterije tip=tmr.findById(idTM).get();
			c.setTipmusterije(tip);
			c.setDatumOd(datumOd);
			c.setDatumDo(datumDo);
			
			cr.save(c);
			
			Korisnik k=new Korisnik();
			k.setIme(ime);
			k.setPrezime(prezime);
			k.setUsername(username);
			k.setPassword(nova_sif);
			k.setBrlk(brlk);

			Uloga uloga=ulr.getById(3); //musterija ima id 3, a znamo da je ovo musterija jer bas njega unosimo
			k.getUlogas().add(uloga);
			for(Uloga u:k.getUlogas()) {
				u.getKorisniks().add(k); //dozvolili da 1 korisnik moze imati vise uloga(Mozda neki zaposleni zeli masazu da zakaze pa je onda on musterija)
			}
			
			kr.save(k);
			
			Musterija m=new Musterija();
			m.setIme(ime);
			m.setPrezime(prezime);
			m.setBrlk(brlk);
			m.setUsername(username);
			m.setPassword(nova_sif);
			m.setClanarina(c);
			
			m=mr.save(m);
			
			//c.addMusterija(m);
			
			uspesnaMusterija="Uspesno dodata musterija.";
			}catch(Exception ex) {
				ex.printStackTrace();
				uspesnaMusterija="Niste uspeli dodati musteriju.";
			}

			request.getSession().setAttribute("uspesnaMusterija", uspesnaMusterija);
			
			return "unosMusterije";
		}
		
	
	@InitBinder
	public void initBinder(WebDataBinder binder) {
	    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
	    dateFormat.setLenient(true);
	    binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true));
	}
	
	
	
	
}

