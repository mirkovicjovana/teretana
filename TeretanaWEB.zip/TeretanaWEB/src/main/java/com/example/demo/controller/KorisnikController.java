package com.example.demo.controller;

import java.io.IOException;
import java.security.Principal;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.demo.repository.AdministratorRepository;
import com.example.demo.repository.KorisnikRepository;
import com.example.demo.repository.UlogaRepository;
import com.example.demo.repository.ZaposleniRepository;

import model.Administrator;
import model.Korisnik;
import model.Uloga;
import model.Zaposleni;

@Controller
@ControllerAdvice
@RequestMapping(value="user")
public class KorisnikController {

	@Autowired
	KorisnikRepository kr;
	
	@Autowired
	UlogaRepository ur;
	
	@Autowired
	AdministratorRepository ar;
	
	@Autowired
	ZaposleniRepository zr;
	
//	@RequestMapping(value = "registerUser", method = RequestMethod.GET)
//		public String (Model model) {
//		Korisnik korisnik=new Korisnik();
//		model.addAttribute("user", korisnik);
//		return "user/register";
//	}
	
	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public String registracija(String ime, String prezime, String username, String password,HttpServletRequest request) {
		try {
			BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
			BCryptPasswordEncoder passwordEncoder2 = new BCryptPasswordEncoder();


			Korisnik k = new Korisnik();
			
			Integer idUloga=Integer.parseInt(request.getParameter("idUloga"));
			Uloga uloga=ur.findById(idUloga).get();

			k.setIme(ime);
			k.setPrezime(prezime);
			k.setUsername(username);
			k.setPassword(passwordEncoder.encode(password));
			k.getUlogas().add(uloga);
						
			for(Uloga u:k.getUlogas()) {
				u.getKorisniks().add(k);
			}
			
			kr.save(k);
			
			Integer idKorisnika=k.getIdK();

			if(idUloga==1) {
				Administrator admin=new Administrator();
				admin.setIdA(idKorisnika);
				admin.setIme(ime);
				admin.setPrezime(prezime);
				admin.setBrlk(null); //DOVUCI I TO IZ FORME!!
				admin.setPassword(passwordEncoder2.encode(password));
				admin.setUsername(username);
				
				ar.save(admin);
			}else if(idUloga==2) {
				System.out.println("id korisnik je"+idKorisnika);
				Zaposleni z=new Zaposleni();
				z.setIdZ(idKorisnika);
				System.out.println("id zap je"+z.getIdZ());
				z.setIme(ime);
				z.setPrezime(prezime);
				z.setBrlk(null); //DOVUCI I TO IZ FORME!!
				z.setPassword(passwordEncoder2.encode(password));
				z.setUsername(username);
				
				zr.save(z);
				System.out.println("id zap posle save je"+z.getIdZ());

			}

			return "login";
		} catch (Exception ex) {
			ex.printStackTrace();
			return "error";
		}
		}
	
	//logovanje registrovanih korisnika
	   @RequestMapping(value = "/loginPage", method = RequestMethod.GET)
	    public String loginPage() {    
	    	return "login";
	    }
	   
	   @RequestMapping(value = "/sveUloge", method = RequestMethod.GET)
	    public String getSveUloge(Model m) {    
		   List<Uloga> sveUloge=ur.findAll();
		   m.addAttribute("uloge", sveUloge);
		   return "register";
	    }
	   
//	   @RequestMapping(value="/welcome", method = RequestMethod.GET)
//	    public String getPocetna (){
//	       
//	        return "welcome";
//	    }
	   
		@RequestMapping(value = "logout", method = RequestMethod.GET)
		public String logout() {
			//System.err.println("-------------------------------------------------------------------------");
			System.err.println("Odjavili ste se!");
			Authentication user = SecurityContextHolder.getContext().getAuthentication();
			
			if (user != null) {
				SecurityContextHolder.getContext().setAuthentication(null);
			}
			
			return "redirect:/user/loginPage";
		}
	   
	   
	   @ResponseBody
		 @RequestMapping(value = "/welcome" , method = RequestMethod.GET)
		 public void pocetna(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			// System.err.println("--------------------------------------------------------------------------------");
			 Principal principal = request.getUserPrincipal();
			 String username = principal.getName();
			 //System.out.println(username);
			 Korisnik k = kr.findByUsername(username);
			 request.getSession().setAttribute("logovanKorisnik", k);
			 request.getRequestDispatcher("/welcome.jsp").forward(request, response);;
		 }
}
