package com.example.demo.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.example.demo.repository.KomentarRepository;
import com.example.demo.repository.KorisnikRepository;
import com.example.demo.repository.MusterijaRepository;
import com.example.demo.repository.TerminRepository;
import com.example.demo.repository.UslugaRepository;

import model.Clanarina;
import model.Komentar;
import model.Korisnik;
import model.Musterija;
import model.Termin;
import model.Tipusluge;
import model.Usluga;

@Controller
@ControllerAdvice
@RequestMapping(value="/musterija")
public class MusterijaController {

	@Autowired
	UslugaRepository ur;

	@Autowired
	KorisnikRepository kr;
	
	@Autowired
	TerminRepository tr;
	
	@Autowired
	MusterijaRepository mr;
	
	@Autowired
	KomentarRepository kor;
	
	@RequestMapping(value = "/sveUslugeCB", method = RequestMethod.GET)
	public String sveUslugeCB(HttpServletRequest request,Model m) {
		
		List<Usluga> usluge=ur.findAll();
		request.getSession().setAttribute("uslugeCB",usluge);
		return "prikazUslugaMusterija";
	}
	
	
	//prikazuju se samo termini koji nisu vec rezervisani(kojima je indikator postavljen na 0)
	@RequestMapping(value = "/sviTermini", method = RequestMethod.GET)
	public String sviTerminiZaUslugu(HttpServletRequest request,Model m) {
		Integer idUsl=Integer.parseInt(request.getParameter("idUsluge"));
		Usluga u=ur.findById(idUsl).get();
		List<Termin> termini=tr.findSlobodanZaUslugu(u);
		request.getSession().setAttribute("termini", termini);
		return "prikazTermina";
	}
	
	@RequestMapping(value = "/rezervacijaTermina", method = RequestMethod.GET)
	public String rezervisanjeTermina(HttpServletRequest request) {
		String zakazivanjeUspesnost="";
		Integer idT=Integer.parseInt(request.getParameter("idTermina"));
		Termin t=tr.findById(idT).get();
		Usluga u=t.getUsluga();
		Tipusluge tu=u.getTipusluge();
		
		//izvucemo trenutno ulogovanog korisnika iz sesije(stavili smo ga tu u metodi pocetna u KorisnikController
		Korisnik k=(Korisnik) request.getSession().getAttribute("logovanKorisnik");
		//izvucemo iz tabele Musterija tog Korisnika preko username-a
		Musterija m=mr.findByUsername(k.getUsername());
		
//		m.getTermins().add(t); //1 musterija  moze imati vise termina
//		t.getMusterijas().add(m); //Jedan termin moze rezervisati vise osoba zbog grupnih
		m.getTermins().add(t);
		
		for(Termin termin:m.getTermins()) {
			termin.getMusterijas().add(m);
		}
		
		//za grupne treninge ogranicimo broj rezervacija na 30
		//ako je individualni trening ili neka od spa usluga obrisemo odmah termin iz ponude jer je upravo rezervisan
		if((tu.getNazivTipa().equals("grupniTrening") && t.getMusterijas().size()>29) ||
				(tu.getNazivTipa().equals("individualniTrening")) ||
						tu.getNazivTipa().equals("spa")) {
			try {
			//tr.delete(t); //Ne prikazuj vise ovaj termin jer je popunjen
				t.setIndikatorPopunjenosti(1); 
				tr.save(t);
			zakazivanjeUspesnost="Uspesno ste rezervisali svoj termin. Ocekujemo Vas!";
			}catch(Exception ex) {
				ex.printStackTrace();
				zakazivanjeUspesnost="Niste uspeli rezervisati termin.";
			}
		}
		request.setAttribute("zakazivanjeUspesnost", zakazivanjeUspesnost);
		return "prikazUslugaMusterija";
	}

	
	@RequestMapping(value = "/proveraClanarine", method = RequestMethod.GET)
	public String proveraClanarine(HttpServletRequest request,Model model) {
		Korisnik k=(Korisnik) request.getSession().getAttribute("logovanKorisnik");
		Musterija m=mr.findByUsername(k.getUsername());
		System.out.println(k+"\n");
		System.out.println(m+"\n");
		Clanarina c=m.getClanarina();
		System.out.println(c+"\n");
		model.addAttribute("clanarina",c);
		return "clanarina";
	}
	
	@RequestMapping(value = "/updateForma", method = RequestMethod.GET)
	public String updateForma(HttpServletRequest request,Model model) {
		String prikaziFormu="prikaziformu";
		request.getSession().setAttribute("prikaziFormu", prikaziFormu);
		return "updateMusterija";
	}
	
	@RequestMapping(value = "/promenaPodataka", method = RequestMethod.POST)
	public String promenaPodataka(HttpServletRequest request,String username,String sifra) {
		String updateUspesnost="";
		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		String nova_sif=passwordEncoder.encode(sifra);
		//BCryptPasswordEncoder passwordEncoder2 = new BCryptPasswordEncoder();

		try {
		
		Korisnik k=(Korisnik) request.getSession().getAttribute("logovanKorisnik");
		Musterija m=mr.findByUsername(k.getUsername());
		
		m.setUsername(username);
		m.setPassword(nova_sif);
		k.setUsername(username);
		k.setPassword(nova_sif);
		
		mr.save(m);
		kr.save(k);
		
			updateUspesnost="Uspesno ste promenili svoj username i password";
		}catch(Exception ex) {
			ex.printStackTrace();
			updateUspesnost="Niste uspeli promeniti username i password.";
		}
		
		request.setAttribute("updateUspesnost", updateUspesnost);
		
		return "updateMusterija";
	}
	
	
	@RequestMapping(value = "/komentari", method = RequestMethod.POST)
	public String saveKomentar(HttpServletRequest request,String kom) {
		try {
			Komentar k=new Komentar();
			Korisnik korisnik=(Korisnik) request.getSession().getAttribute("logovanKorisnik");
			Musterija m=mr.findByUsername(korisnik.getUsername());
			k.setText(kom);
			k.setMusterija(m);
			kor.save(k);
			request.setAttribute("uspesanKom", "Uspesno ste postavili komentar.Hvala Vam na izdvojenom vremenu.");
		}catch(Exception ex) {
			ex.printStackTrace();
			request.setAttribute("uspesanKom", "Niste uspeli postaviti komentar.");

		}
		
		return "komentari";
		
	}
	
	@InitBinder
	public void initBinder(WebDataBinder binder) {
	    SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy"); //yyyy-MM-dd
	    dateFormat.setLenient(true);
	    binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true));
	}
}
