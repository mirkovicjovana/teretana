package com.example.demo.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.example.demo.repository.FotografijaRepository;
import com.example.demo.repository.UslugaRepository;

import model.Fotografija;
import model.Usluga;

@Controller
@RequestMapping("/usluga") 
public class UslugaController {
	
	@Autowired
	UslugaRepository ur;

	@Autowired
	FotografijaRepository fr;


	@RequestMapping(value = "/getSve", method = RequestMethod.GET)
	public String getSveUsluge(Model model){
		List<Usluga> sveUsluge=ur.findAll();
		model.addAttribute("sveUsluge", sveUsluge);
		return "spisakUsluga";
	}

	@RequestMapping(value = "/uslugeZaGaleriju", method = RequestMethod.GET)
	public String getSveUsluge2(HttpServletRequest request){
		List<Usluga> sveUsluge2=ur.findAll();
		request.getSession().setAttribute("sveUsluge2", sveUsluge2);
		return "galerija";
	}
	
	
	
	@RequestMapping(value = "/sveSlike", method = RequestMethod.GET)
	public String sveSlike(HttpServletRequest request) {
		Integer idUsluge=Integer.parseInt(request.getParameter("idUsluge"));
		Usluga u=ur.findById(idUsluge).get();
		List<Fotografija> slike=fr.findByUsluga(u);
		request.getSession().setAttribute("sveSlike", slike);
		request.getSession().setAttribute("izabranaUsluga", u);
		return "galerija";
	}
	
}
