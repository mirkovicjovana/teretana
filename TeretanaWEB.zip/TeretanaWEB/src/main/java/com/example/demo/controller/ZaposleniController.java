package com.example.demo.controller;

import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.example.demo.repository.KorisnikRepository;
import com.example.demo.repository.MusterijaRepository;
import com.example.demo.repository.TerminRepository;
import com.example.demo.repository.ZaposleniRepository;

import model.Korisnik;
import model.Smena;
import model.Termin;
import model.Zaposleni;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

@Controller
@ControllerAdvice
@RequestMapping(value="/zap")
public class ZaposleniController {
	
	@Autowired
	KorisnikRepository kr;
	
	@Autowired
	ZaposleniRepository zr;
	
	@Autowired
	TerminRepository tr;
	
	@Autowired
	MusterijaRepository mr;
	
	@RequestMapping(value = "/updateForma", method = RequestMethod.GET)
	public String updateForma(HttpServletRequest request,Model model) {
		String prikaziFormu="prikaziformu";
		request.setAttribute("prikaziFormu", prikaziFormu);
		return "updateZaposleni";
	}
	
	@RequestMapping(value = "/pregledPlate", method = RequestMethod.GET)
	public String proveraPlate(HttpServletRequest request,Model model) {
		Korisnik k=(Korisnik) request.getSession().getAttribute("logovanKorisnik");
		Zaposleni z=zr.findByUsername(k.getUsername());
		request.setAttribute("zaposleni",z);
		return "plata";
	}
	
	@RequestMapping(value = "/updatePodataka", method = RequestMethod.POST)
	public String promenaPodataka(HttpServletRequest request,String username,String sifra) {
		String updateUspesnost="";
		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		//BCryptPasswordEncoder passwordEncoder2 = new BCryptPasswordEncoder();
		String nova_sif=passwordEncoder.encode(sifra);
		try {
		
		Korisnik k=(Korisnik) request.getSession().getAttribute("logovanKorisnik");
		Zaposleni m=zr.findByUsername(k.getUsername());
		
		m.setUsername(username);
		m.setPassword(nova_sif);
		k.setUsername(username);
		k.setPassword(nova_sif);
		
		zr.save(m);
		kr.save(k);
		
			updateUspesnost="Uspesno ste promenili svoj username i password";
		}catch(Exception ex) {
			ex.printStackTrace();
			updateUspesnost="Niste uspeli promeniti username i password.";
		}
		
		request.setAttribute("updateUspesnost", updateUspesnost);
		
		return "updateZaposleni";
	}
	
	@RequestMapping(value = "/pregledTermina", method = RequestMethod.GET)
	public String pregledZakazanihTermina(HttpServletRequest request,Model model) {
		Korisnik k=(Korisnik) request.getSession().getAttribute("logovanKorisnik");
		Zaposleni z=zr.findByUsername(k.getUsername());
		
		List<Termin> termini=tr.findByZaposleni(z);
	
		Smena s=z.getSmena();
		
		
		request.getSession().setAttribute("smena", s);

		request.getSession().setAttribute("termini", termini);
		
		return "terminiZaposleni";
		
	}
	
	@RequestMapping(value="/getSveMusterije", method=RequestMethod.GET)
	public void showReport(HttpServletResponse response) throws Exception{
		JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(mr.findAll());
		InputStream inputStream = this.getClass().getResourceAsStream("/jasperreports/Report.jrxml");
		JasperReport jasperReport = JasperCompileManager.compileReport(inputStream);
		Map<String, Object> params = new HashMap<String, Object>();
		JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, params, dataSource);
		inputStream.close();
		
		
		response.setContentType("application/x-download");
		response.addHeader("Content-disposition", "attachment; filename=SveMusterije.pdf");
		OutputStream out = response.getOutputStream();
		JasperExportManager.exportReportToPdfStream(jasperPrint,out);
	}

	
	@InitBinder
	public void initBinder(WebDataBinder binder) {
	    SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy"); //yyyy-MM-dd
	    dateFormat.setLenient(true);
	    binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true));
	}
	}
