//Prekopirano od Lidije iz security->RoleConverter
package com.example.demo.converter;

import org.springframework.core.convert.ConversionFailedException;

import com.example.demo.repository.UlogaRepository;

import model.Uloga;

import org.springframework.core.convert.ConversionFailedException;
import org.springframework.core.convert.TypeDescriptor;
import org.springframework.core.convert.converter.Converter;

public class UlogaConverter implements Converter<String, Uloga>{

UlogaRepository r;
	
	public UlogaConverter(UlogaRepository r){
		this.r=r;
	}
	
	public Uloga convert(String source) {
			  int idRole=-1;
		       try{
		    	   idRole=Integer.parseInt(source);
		       }
		       catch(NumberFormatException e){
		    	   throw new ConversionFailedException(TypeDescriptor.valueOf(String.class), TypeDescriptor.valueOf(Uloga.class),idRole, null);
		       }
		       Uloga role=r.getById(idRole);
		      return role;
		  }
}
