package com.example.demo.domain;

import java.io.Serializable;

import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;

import org.springframework.web.multipart.MultipartFile;

import model.Tipusluge;

public class UslugaSlika implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id
	private int idU;
	
private String naziv;
	
	private int cena;
	
	//bi-directional many-to-one association to Tipusluge
		@ManyToOne
		@JoinColumn(name="tipUsluge")
		private Tipusluge tipusluge;
	
	private MultipartFile slika;
	
	public UslugaSlika() {}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public int getIdU() {
		return idU;
	}

	public MultipartFile getSlika() {
		return slika;
	}

	public void setIdU(int idU) {
		this.idU = idU;
	}

	public void setSlika(MultipartFile slika) {
		this.slika = slika;
	}
	
	
}
