package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import model.Clanarina;
import model.Tipmusterije;

public interface ClanarinaRepository extends JpaRepository<Clanarina,Integer>{
	public Clanarina findByTipmusterije(Tipmusterije tip);
}
