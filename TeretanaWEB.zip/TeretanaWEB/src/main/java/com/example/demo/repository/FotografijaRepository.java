package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import model.Fotografija;
import model.Usluga;

public interface FotografijaRepository extends JpaRepository<Fotografija,Integer> {

	public List<Fotografija> findByUsluga(Usluga u);
}
