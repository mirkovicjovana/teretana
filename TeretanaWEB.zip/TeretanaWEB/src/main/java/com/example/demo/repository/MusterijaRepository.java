package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import model.Musterija;

public interface MusterijaRepository extends JpaRepository<Musterija,Integer>{
	
	public Musterija findByUsername(String username);
	

}
