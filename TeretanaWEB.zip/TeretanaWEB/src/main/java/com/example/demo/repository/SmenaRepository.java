package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import model.Smena;

public interface SmenaRepository extends JpaRepository<Smena,Integer>{

}
