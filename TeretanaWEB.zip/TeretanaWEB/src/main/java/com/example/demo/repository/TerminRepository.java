package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import model.Termin;
import model.Usluga;
import model.Zaposleni;

public interface TerminRepository extends JpaRepository<Termin,Integer>{
	
	//pronalazi sve termine za datu uslugu
	public List<Termin> findByUsluga(Usluga u);

	//pronalazi samo termine koji su slobodni-inidikator=0
	@Query("SELECT t FROM Termin t WHERE t.usluga=:usluga AND t.indikatorPopunjenosti=0")
	public List<Termin> findSlobodanZaUslugu(@Param("usluga")Usluga u);
	
	public List<Termin> findByZaposleni(Zaposleni z);
}
