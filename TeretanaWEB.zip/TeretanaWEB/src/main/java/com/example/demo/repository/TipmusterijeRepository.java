package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import model.Tipmusterije;

public interface TipmusterijeRepository extends JpaRepository<Tipmusterije, Integer>{

}
