package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import model.Tipusluge;

public interface TipuslugeRepository extends JpaRepository<Tipusluge,Integer> {

}
