package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import model.Uloga;

public interface UlogaRepository extends JpaRepository<Uloga,Integer>{

}
