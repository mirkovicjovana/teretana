package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import model.Tipusluge;
import model.Usluga;
import model.Zaposleni;

public interface ZaposleniRepository extends JpaRepository<Zaposleni,Integer>{
	
	public Zaposleni findByUsername(String username);
	public List<Zaposleni> findAllByUsluga(Usluga usluga);

}
