package model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the fotografija database table.
 * 
 */
@Entity
@NamedQuery(name="Fotografija.findAll", query="SELECT f FROM Fotografija f")
public class Fotografija implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int idF;

	private String url;

	//bi-directional many-to-one association to Usluga
	@ManyToOne
	@JoinColumn(name="idUsl")
	private Usluga usluga;

	public Fotografija() {
	}

	public int getIdF() {
		return this.idF;
	}

	public void setIdF(int idF) {
		this.idF = idF;
	}

	public String getUrl() {
		return this.url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public Usluga getUsluga() {
		return this.usluga;
	}

	public void setUsluga(Usluga usluga) {
		this.usluga = usluga;
	}

}