package model;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;


/**
 * The persistent class for the musterija database table.
 * 
 */
@Entity
@NamedQuery(name="Musterija.findAll", query="SELECT m FROM Musterija m")
public class Musterija implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int idM;

	private String brlk;

	private String ime;

	private String password;

	private String prezime;

	private String username;

	//bi-directional many-to-one association to Clanarina
	@ManyToOne
	@JoinColumn(name="idClanarine")
	private Clanarina clanarina;
	
	//bi-directional many-to-many association to Termin
		@ManyToMany(fetch = FetchType.EAGER)
		@JoinTable(name="Zakazanitermin", joinColumns = @JoinColumn(name = "idMus",referencedColumnName = "idM"),inverseJoinColumns = @JoinColumn(name = "idTermina"))
		private Set<Termin> termins =new HashSet<>();

	public Musterija() {
	}

	public int getIdM() {
		return this.idM;
	}

	public void setIdM(int idM) {
		this.idM = idM;
	}

	public String getBrlk() {
		return this.brlk;
	}

	public void setBrlk(String brlk) {
		this.brlk = brlk;
	}

	public String getIme() {
		return this.ime;
	}

	public void setIme(String ime) {
		this.ime = ime;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPrezime() {
		return this.prezime;
	}

	public void setPrezime(String prezime) {
		this.prezime = prezime;
	}

	public String getUsername() {
		return this.username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public Clanarina getClanarina() {
		return this.clanarina;
	}

	public void setClanarina(Clanarina clanarina) {
		this.clanarina = clanarina;
	}

	public Set<Termin> getTermins() {
		return termins;
	}

	public void setTermins(Set<Termin> termins) {
		this.termins = termins;
	}

	
}