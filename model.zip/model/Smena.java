package model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the smena database table.
 * 
 */
@Entity
@NamedQuery(name="Smena.findAll", query="SELECT s FROM Smena s")
public class Smena implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int idS;

	private String naziv;

	private String vreme;

	//bi-directional many-to-one association to Zaposleni
	@OneToMany(mappedBy="smena")
	private List<Zaposleni> zaposlenis;

	public Smena() {
	}

	public int getIdS() {
		return this.idS;
	}

	public void setIdS(int idS) {
		this.idS = idS;
	}

	public String getNaziv() {
		return this.naziv;
	}

	public void setNaziv(String naziv) {
		this.naziv = naziv;
	}

	public String getVreme() {
		return this.vreme;
	}

	public void setVreme(String vreme) {
		this.vreme = vreme;
	}

	public List<Zaposleni> getZaposlenis() {
		return this.zaposlenis;
	}

	public void setZaposlenis(List<Zaposleni> zaposlenis) {
		this.zaposlenis = zaposlenis;
	}

	public Zaposleni addZaposleni(Zaposleni zaposleni) {
		getZaposlenis().add(zaposleni);
		zaposleni.setSmena(this);

		return zaposleni;
	}

	public Zaposleni removeZaposleni(Zaposleni zaposleni) {
		getZaposlenis().remove(zaposleni);
		zaposleni.setSmena(null);

		return zaposleni;
	}

}