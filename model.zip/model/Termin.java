package model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the termin database table.
 * 
 */
@Entity
@NamedQuery(name="Termin.findAll", query="SELECT t FROM Termin t")
public class Termin implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int idT;

	@Temporal(TemporalType.DATE)
	private Date datum;

	private int idUsluge;

	private int idZap;

	private int indikatorPopunjenosti;

	private String vreme;

	public Termin() {
	}

	public int getIdT() {
		return this.idT;
	}

	public void setIdT(int idT) {
		this.idT = idT;
	}

	public Date getDatum() {
		return this.datum;
	}

	public void setDatum(Date datum) {
		this.datum = datum;
	}

	public int getIdUsluge() {
		return this.idUsluge;
	}

	public void setIdUsluge(int idUsluge) {
		this.idUsluge = idUsluge;
	}

	public int getIdZap() {
		return this.idZap;
	}

	public void setIdZap(int idZap) {
		this.idZap = idZap;
	}

	public int getIndikatorPopunjenosti() {
		return this.indikatorPopunjenosti;
	}

	public void setIndikatorPopunjenosti(int indikatorPopunjenosti) {
		this.indikatorPopunjenosti = indikatorPopunjenosti;
	}

	public String getVreme() {
		return this.vreme;
	}

	public void setVreme(String vreme) {
		this.vreme = vreme;
	}

}