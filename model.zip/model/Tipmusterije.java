package model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the tipmusterije database table.
 * 
 */
@Entity
@NamedQuery(name="Tipmusterije.findAll", query="SELECT t FROM Tipmusterije t")
public class Tipmusterije implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int idTipaM;

	private float iznos;

	private String nazivTipaM;

	public Tipmusterije() {
	}

	public int getIdTipaM() {
		return this.idTipaM;
	}

	public void setIdTipaM(int idTipaM) {
		this.idTipaM = idTipaM;
	}

	public float getIznos() {
		return this.iznos;
	}

	public void setIznos(float iznos) {
		this.iznos = iznos;
	}

	public String getNazivTipaM() {
		return this.nazivTipaM;
	}

	public void setNazivTipaM(String nazivTipaM) {
		this.nazivTipaM = nazivTipaM;
	}

}