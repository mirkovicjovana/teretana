package model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the tipusluge database table.
 * 
 */
@Entity
@NamedQuery(name="Tipusluge.findAll", query="SELECT t FROM Tipusluge t")
public class Tipusluge implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int idTipa;

	private String nazivTipa;

	//bi-directional many-to-one association to Usluga
	@OneToMany(mappedBy="tipusluge")
	private List<Usluga> uslugas;

	public Tipusluge() {
	}

	public int getIdTipa() {
		return this.idTipa;
	}

	public void setIdTipa(int idTipa) {
		this.idTipa = idTipa;
	}

	public String getNazivTipa() {
		return this.nazivTipa;
	}

	public void setNazivTipa(String nazivTipa) {
		this.nazivTipa = nazivTipa;
	}

	public List<Usluga> getUslugas() {
		return this.uslugas;
	}

	public void setUslugas(List<Usluga> uslugas) {
		this.uslugas = uslugas;
	}

	public Usluga addUsluga(Usluga usluga) {
		getUslugas().add(usluga);
		usluga.setTipusluge(this);

		return usluga;
	}

	public Usluga removeUsluga(Usluga usluga) {
		getUslugas().remove(usluga);
		usluga.setTipusluge(null);

		return usluga;
	}

}