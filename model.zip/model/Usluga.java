package model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the usluga database table.
 * 
 */
@Entity
@NamedQuery(name="Usluga.findAll", query="SELECT u FROM Usluga u")
public class Usluga implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int idU;

	private int cena;

	private String naziv;

	@Lob
	private byte[] slika;

	//bi-directional many-to-one association to Fotografija
	@OneToMany(mappedBy="usluga")
	private List<Fotografija> fotografijas;

	//bi-directional many-to-one association to Termin
	@OneToMany(mappedBy="usluga")
	private List<Termin> termins;

	//bi-directional many-to-one association to Tipusluge
	@ManyToOne
	@JoinColumn(name="tipUsluge")
	private Tipusluge tipusluge;

	//bi-directional many-to-one association to Zaposleni
	@OneToMany(mappedBy="usluga")
	private List<Zaposleni> zaposlenis;

	public Usluga() {
	}

	public int getIdU() {
		return this.idU;
	}

	public void setIdU(int idU) {
		this.idU = idU;
	}

	public int getCena() {
		return this.cena;
	}

	public void setCena(int cena) {
		this.cena = cena;
	}

	public String getNaziv() {
		return this.naziv;
	}

	public void setNaziv(String naziv) {
		this.naziv = naziv;
	}

	public byte[] getSlika() {
		return this.slika;
	}

	public void setSlika(byte[] slika) {
		this.slika = slika;
	}

	public List<Fotografija> getFotografijas() {
		return this.fotografijas;
	}

	public void setFotografijas(List<Fotografija> fotografijas) {
		this.fotografijas = fotografijas;
	}

	public Fotografija addFotografija(Fotografija fotografija) {
		getFotografijas().add(fotografija);
		fotografija.setUsluga(this);

		return fotografija;
	}

	public Fotografija removeFotografija(Fotografija fotografija) {
		getFotografijas().remove(fotografija);
		fotografija.setUsluga(null);

		return fotografija;
	}

	public List<Termin> getTermins() {
		return this.termins;
	}

	public void setTermins(List<Termin> termins) {
		this.termins = termins;
	}

	public Termin addTermin(Termin termin) {
		getTermins().add(termin);
		termin.setUsluga(this);

		return termin;
	}

	public Termin removeTermin(Termin termin) {
		getTermins().remove(termin);
		termin.setUsluga(null);

		return termin;
	}

	public Tipusluge getTipusluge() {
		return this.tipusluge;
	}

	public void setTipusluge(Tipusluge tipusluge) {
		this.tipusluge = tipusluge;
	}

	public List<Zaposleni> getZaposlenis() {
		return this.zaposlenis;
	}

	public void setZaposlenis(List<Zaposleni> zaposlenis) {
		this.zaposlenis = zaposlenis;
	}

	public Zaposleni addZaposleni(Zaposleni zaposleni) {
		getZaposlenis().add(zaposleni);
		zaposleni.setUsluga(this);

		return zaposleni;
	}

	public Zaposleni removeZaposleni(Zaposleni zaposleni) {
		getZaposlenis().remove(zaposleni);
		zaposleni.setUsluga(null);

		return zaposleni;
	}

}