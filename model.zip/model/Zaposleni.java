package model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the zaposleni database table.
 * 
 */
@Entity
@NamedQuery(name="Zaposleni.findAll", query="SELECT z FROM Zaposleni z")
public class Zaposleni implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int idZ;

	private String brlk;

	private String ime;

	private String password;

	private int plata;

	private String prezime;

	private String username;

	//bi-directional many-to-one association to Termin
	@OneToMany(mappedBy="zaposleni")
	private List<Termin> termins;

	//bi-directional many-to-one association to Smena
	@ManyToOne
	@JoinColumn(name="idSmene")
	private Smena smena;

	//bi-directional many-to-one association to Usluga
	@ManyToOne
	@JoinColumn(name="idUsluge")
	private Usluga usluga;

	public Zaposleni() {
	}

	public int getIdZ() {
		return this.idZ;
	}

	public void setIdZ(int idZ) {
		this.idZ = idZ;
	}

	public String getBrlk() {
		return this.brlk;
	}

	public void setBrlk(String brlk) {
		this.brlk = brlk;
	}

	public String getIme() {
		return this.ime;
	}

	public void setIme(String ime) {
		this.ime = ime;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getPlata() {
		return this.plata;
	}

	public void setPlata(int plata) {
		this.plata = plata;
	}

	public String getPrezime() {
		return this.prezime;
	}

	public void setPrezime(String prezime) {
		this.prezime = prezime;
	}

	public String getUsername() {
		return this.username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public List<Termin> getTermins() {
		return this.termins;
	}

	public void setTermins(List<Termin> termins) {
		this.termins = termins;
	}

	public Termin addTermin(Termin termin) {
		getTermins().add(termin);
		termin.setZaposleni(this);

		return termin;
	}

	public Termin removeTermin(Termin termin) {
		getTermins().remove(termin);
		termin.setZaposleni(null);

		return termin;
	}

	public Smena getSmena() {
		return this.smena;
	}

	public void setSmena(Smena smena) {
		this.smena = smena;
	}

	public Usluga getUsluga() {
		return this.usluga;
	}

	public void setUsluga(Usluga usluga) {
		this.usluga = usluga;
	}

}